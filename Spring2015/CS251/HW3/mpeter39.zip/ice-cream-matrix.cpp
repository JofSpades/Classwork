#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <ctime>
using namespace std;

//for time keeping and comparison
struct timeval tvalBefore, tvalAfter;

/*
 * +---------------------------------------------+
 * | Authors: Stephen Selke & Maxwell Petersen   |
 * | Emails: (sselke2||mpeter39)@uic.edu         |
 * | Program 3: Ice Cream (dominance problem)    |
 * +---------------------------------------------+
 * | Tested on: 2.6GHz 8GB Macbook Pro           |
 * | Also on: 2.5GHz 16GB Lenovo G510 (Ubuntu)   |
 * +---------------------------------------------+
 */

/* 
 * EDIT VERSION 1.3
 * ----------------
 */

 struct Matrix {
 	int** matrix;
 	int size;
 	int found;
 };

/*
 * creating a new matrix of set size
 * and setting all fields to zero
 */
int** newMatrix(int size) {
 	int fixedSize = size + 1;
	int** matrix = new int*[fixedSize]; // +1 because vertex count starts at 1 not 0
	int i, j;
	for(i = 0; i < fixedSize; i++) {
		matrix[i] = new int[fixedSize];
		for(j = 0; j < fixedSize; j++) {
			matrix[i][j] = 0;
		}
	}
	return matrix;
}

/*
 * updates entries in the matrix
 */
void updateMatrix(int** matrix, int input[], int n) {
 	int i;
	for(i = 1; i < n; i++) { // starts at 1 to avoid first vertex input[0]
		matrix[input[0]][input[i]] = 1;
		matrix[input[i]][input[0]] = 1;
	}
	matrix[input[0]][0] = n;
	matrix[0][input[0]] = n;
}

/*
 * prints out matrix [rows][cols]
 */
void printMatrix(Matrix* matrix) {
 	int i, j;
 	for(i = 1; i < matrix->size + 1; i++) {
 		for(j = 1; j < matrix->size + 1; j++) {
 			if(matrix->matrix[i][j] == 0){
 				cout << "  ";
 			} else {
 				cout << matrix->matrix[i][j] << " ";
 			}
 		}
 		cout << "\n";
 	}
}

void printArray(int arr[], int n) {
 	int i;
 	for(i = 0; i < n; i++) {
 		cout << arr[i] << " ";
 	}
 	cout << "\n";
 }

/*
 * this fuction reads in the file and 
 * populates the matrix array within 
 * the Matrix struct.
 */
Matrix* populateMatrix(char* filename) {
 	Matrix* m = new Matrix;
 	FILE* file = fopen(filename, "r");
 	char buffer[256];
 	int numberBuffer[256];
 	int** matrix;
 	int i = 0, j = 0, number, atLine = 0, size = 0;
 	while((buffer[i] = fgetc(file)) && buffer[i] != EOF) {
		if(buffer[i] == ' ' || buffer[i] == '\n') { // must be the end of a number
			buffer[i+1] = '\0';
			number = atoi(buffer);
			numberBuffer[j] = number;
			j++;
			if(buffer[i] == '\n') { // end of set
				if(atLine == 0) { // the number of vertices given on this line
					size = numberBuffer[0];
					matrix = newMatrix(size);
				}
				else {
					updateMatrix(matrix, numberBuffer, j);
				}
				j = 0;
				atLine++;
			}
			i = 0;
		}
		else {
			i++;
		}
	}
	if(i > 0) { // there might still be one left!
		buffer[i+1] = '\0';
		number = atoi(buffer);
		numberBuffer[j] = number;
		j++;
		updateMatrix(matrix, numberBuffer, j);
	}
	fclose(file);
	m->matrix = matrix;
	m->size = size;
	return m;
}

//used to initlize the arays to 0
void initlizeArray(int inArr[], int size){
	int i = 1;

	for(i; i <= size; i+= 4){

		inArr[i] = 0;
		inArr[i + 1] = 0;
		inArr[i + 2] = 0;
		inArr[i + 3] = 0;

	}

	if(i > size){

		for(i -= 4 ; i <= size; i++){
			inArr[i] = 0;
		}

	}	
}

//This section of code was taken then modified from combinations.cpp at
//https://wwsw.dropbox.com/sh/hst46kb07qqed4b/AADWCbE5L-w76oIjH3dVN_6qa/Graph/combinations.cpp?dl=0
void combinations (Matrix *&structMatrix, int** matrix, int v[], int checkNodes[], int start, int n, int k, int maxk) {
	int i, j;

    /* k here counts through positions in the maxk-element v.
     * if k > maxk, then the v is complete and we can use it.
     */
     if (k > maxk) {

     	int remember = 0;

 		//counter for how many are needed to be seen still
     	int countLeft = n;
     	initlizeArray(checkNodes, n);

        //run through the matrix looking for which nodes have been touched
     	for(i = 1; i <= maxk; i++){
     		//setting the varible to skip unneeded 0's
     		remember = matrix[v[i]][0];
     		for(j = 1; j <= n; j++){
    			// if the element at the v[i]th row and jth column == 1
    			// while it hasn't been visited yet
     			if((matrix[v[i]][j] == 1 || v[i] == j ) && (checkNodes[j] == 0)){

     				//then the node is covered
     				checkNodes[j] = 1;
     				countLeft--;
     				remember--;


     			}

     			if(remember == 0){

     				//all possible 1's have been found so end
     				break;

     			}

     		}

     	}
     	//looking to see if all nodes are covered
     	if(countLeft != 0){

     		return;

     	}

     	//printout the found set
     	for (i=1; i<=maxk; i++){
     		cout << v[i] << " ";
     	}
     	cout << endl;

     	//indicating that the smallest possible size for the set has been found
     	structMatrix->found = 1;
     	
     	return;
     }

    /* for this k'th element of the v, try all start..n
     * elements in that position
     */
     for (i=start; i<=n; i++) {

     	v[k] = i;
        /* recursively generate combinations of integers
         * from i+1..n
         */
         combinations (structMatrix, matrix, v, checkNodes, i+1, n, k+1, maxk);
     }
}//End of copied and modified code

int skippingMax(int** inMaxtrix, int size){

	//count variable
	int i = 1;

	//skipp size
	int skippSize = 0;
	int temp = 0;

	for(i; i <= size; i+= 4){

		temp += inMaxtrix[i][0];
		temp += inMaxtrix[i + 1][0];
		temp += inMaxtrix[i + 2][0];
		temp += inMaxtrix[i + 3][0];

		temp /= 4;

		skippSize += temp;

		temp = 0;

	}

	if(i > size){

		i -= 4;

		//getting the avrage of all the averages to this point
		skippSize /= i;

		//temp count to know how much to devide by
		int count = 0;

		for(i; i <= size; i++){

			count++;
			temp += inMaxtrix[i][0];

		}

		//getting the final avrages
		temp /= count;
		skippSize += temp;
		skippSize /= 2;

		if(skippSize > 5){

			return skippSize;

		}

		return 5;

	} else {

		//getting the avrage of all the averages to this point
		skippSize /= i;

	}

	if(skippSize > 5){

		return skippSize;
	
	}

	return 5;
}
	
//used to check for any remaining zeros in an array
int hasZeros(int inArr[], int size){
	//count variables
	int i = 1;
	//variable to store the value at the seperate array indexes(as an acumulator)
	int keepTrack = 0;

	for(i; i <= size; i+= 4){
		
		keepTrack += inArr[i];
		keepTrack += inArr[i + 1];
		keepTrack += inArr[i + 2];
		keepTrack += inArr[i + 3];

		if(keepTrack != 4){
			
			return 1;

		}

		keepTrack = 0;

	}

	if(i > size){

		for(i -= 4; i <= size; i++){

			if(inArr[i] == 0){

				return 1;

			}

		}

	}

	return 0;
}

void loadNoOverlap(int matrixSize, int skipVal, int** useMatrix, int onesArr[], int indexArray[],  int& onesLocation, int& index, int passIn){

	//normal counter
	int i;

	// overlap counter
	int overlap = 0;

	for(i = 1; i <= matrixSize; i++){

		if(useMatrix[index][i] & onesArr[i]){
 			//if overlap is found
			overlap++;

			if(overlap > skipVal){
 				//if too much overlap on this end
				index += passIn;
				return;

			}

		}

	}

	//if overlap is fine then store the index into the array
	indexArray[onesLocation] = index;
	onesLocation++;

	//if overlap is fine load in the 1's

	onesArr[index] = 1;

	for(i = 1; i <= matrixSize; i++){

		if(useMatrix[index][i] == 1){

			onesArr[i] = useMatrix[index][i];

	
		}

	}

	index += passIn;
}

//Matrix searching function
void matrixCooralate(Matrix* &matrix, clock_t start){

 	//used to load in the size variable
 	int matrixSize = matrix->size;

    //array used to check for completeness of nodes
 	int checkNodes[matrixSize];

 	//setting the fount value in the matrix struct to 0 as an initlization for use later
 	matrix->found = 0;

	//count variables
	//track is used to make sure to only printout no more than 1000 elements
 	int i, j, track;

 	//array to keep track of what is being use as combos
 	int combosList[matrixSize];

 	//to see if this set size is the smallest found
 	matrix->found = 0;

 	//if checks for more the use of more percise findings
 	if(matrixSize < 100){

 		//check time
 		double totalTime;
 		clock_t intermediate;

 		//Go through the generated matrix to find combonations that cover area.
		//Printing out as it finds combonations that cover all of the vertexes.
 		for(i = 1; i <= matrixSize; i++){

 			//start down the rabbit hole, recursive loop, for the ith size of the set
 			combinations(matrix, matrix->matrix, combosList, checkNodes, 1, matrixSize, 1, i);

 			if(matrix->found == 1){

 				return;

 			}
 			//used to gather time per stage mainly for debug 
 			// intermediate = clock();
 			// totalTime = double(intermediate - start) / CLOCKS_PER_SEC;
 			// printf("DONE WITH SET SIZE: %i TIME IS NOW:%.5fs\n", i, totalTime);

 		}

 	} else {

 		/*
		This method which is only used for large amount of verticies, in this case greater than 100, will run
		through the matrix row by row starting at the opposite ends, i.e. the first and last then the second and
		second to last ect. ect., ony copying in when there is less than a certain amount of over lap which is
		determined by the average coverage minus 2 for a greater value than 1, for incredably sparce/small graphs.
		The next step is to then store the indexes of the used rows into another arry which will be printed out
		once the array which stores the 1's is full.
 		*/

		//start timer
		clock_t check;
		double totalTime;

 		//store 1's and check for minimal overlap using this array
 		int onesArr[matrixSize];

 		//storing the array index;
 		int indexArray[matrixSize];
 		int indexArrayIndex = 0;

 		//pulling the matrix from memory
 		int** useMatrix = matrix->matrix;

 		//setting all values in the array to 0;
 		initlizeArray(onesArr, matrixSize);
 		initlizeArray(indexArray, matrixSize);

 		//using this to shrink the size of matrixSize to gauge the proper spots needed on the upper and lower bounds
 		int bottom = 1;
 		int top = matrixSize;

 		//max number over overlaps allowed before skipping
 		int skipVal = skippingMax(useMatrix, matrixSize);

 		printf("REMINDER THAT AT THIS SIZE ALL THIS FUNCTION DOES IS RETURN A DOMINATE SET\nI AM WELL AWARE THERE ARE SMALLER SETS THAN THE ONE THAT THIS WILL PRINTOUT\n");

 		//actual start checking for any 0's in the array
 		while(hasZeros(onesArr, matrixSize) != 0){

 			//run through the array looking for overlap then load if its fine

 			//bottom run
 			loadNoOverlap(matrixSize, skipVal, useMatrix, onesArr, indexArray, indexArrayIndex, bottom, 1);

 			//top run
 			loadNoOverlap(matrixSize, skipVal, useMatrix, onesArr, indexArray, indexArrayIndex, top, -1);

 			check = clock();
 			totalTime = double(check - start) / CLOCKS_PER_SEC;
 			if(top <= bottom){

 				printf("DONE WITH ITERATIONS TIME IS NOW:%.5fs\nNO SOLUTIONS WERE FOUND\n", totalTime);
 				break;

 			} // else {

 			// 	printf("DONE WITH ITERATION TIME IS NOW:%.5fs\nTOP IS: %i AND BOTTOM IS: %i\n",totalTime, top, bottom);

 			// }

 		}

 		//double check for actual final set
 		if(top > bottom){

 			//print out final set
 			while( indexArray[i] != 0){

 				cout << indexArray[i] << " ";

 				i++;
 			}
 			cout << endl;

 		}

 	}
}

int main(int argc, char* argv[]) {
 	//start matrix timer
 	clock_t start = clock();

 	Matrix* adjacencyMatrix;

 	//fill the matrix
 	adjacencyMatrix = populateMatrix(argv[1]);

 	//start looking for list of smallest possible sets
 	matrixCooralate(adjacencyMatrix, start);

	//printout of time taken for matrix
 	clock_t end = clock();
 	double totalTime = double(end - start) / CLOCKS_PER_SEC;
 	printf("DONE WITH MATRIX\nTIME TAKEN:%.5fs\n",totalTime);
 	//printMatrix(adjacencyMatrix);
}
