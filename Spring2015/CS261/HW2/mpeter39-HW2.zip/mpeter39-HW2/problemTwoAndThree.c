#include <stdlib.h>
#include <stdio.h>
/*
 * Return 1 when x can be represented as an n-bit, 2's complement number; 0 otherwise
 * Assume 1 <= n <= 32
 * Examples: problem2(5, 3) = 0, problem2(-4, 3) = 1
 * Legal ops: ! ~ & ^ | + << >>
 */
int problem2(int x, int n){

	//Setting the shift and setting for the mask value
	n = ~n + 1;
	int shift = 32+n;

	//making the comparing value for x to see if it fits
	int compairingValue = x << shift;
	compairingValue = compairingValue >> shift;
	return !(x ^ compairingValue);

}
/*
 * problem3(x,n,c) - Replace byte n in x with c
 * Bytes numbered fm 0 (LSB) to 3 (MSB)
 * Examples: problem3(0x12345678, 1, 0xab) = 0x1234ab78
 * You can assume 0 <= n <= 3 and 0 <= c <= 255
 * egal ops: ! ~ & ^ | + << >>
 */
int problem3(int x, int n, int c){

	//Making shift amount
	int shiftAmnt = n << 3;

	//making the mask to open up the hole and set the byes for the placement
	int mask = 0xff << shiftAmnt;
	mask = ~mask;

	//aplying the mask and inserting the new byte
	int appliedMask = x & mask;
	int setByte = c << shiftAmnt;
	return (appliedMask | setByte);

}

int main(void){

	printf("problem2(5, 3) = %d\n", problem2(5, 3));
	printf("problem2(-4, 3) = %d\n", problem2(-4, 3));
	printf("problem2(120, 9) = %d\n", problem2(120, 9));
	printf("problem3(0x12345678, 0, 0xab) = %x\n", problem3(0x12345678, 0, 0xab));
	printf("problem3(0x12345678, 1, 0xab) = %x\n", problem3(0x12345678, 1, 0xab));
	printf("problem3(0x12345678, 2, 0xab) = %x\n", problem3(0x12345678, 2, 0xab));
	printf("problem3(0x12345678, 3, 0xab) = %x\n", problem3(0x12345678, 3, 0xab));
	return 0;

}
