/*
Part 1: number of lines for assembly code
    20

Part 2: intration variable
	-8(%ebp) or 0xffffd40

Part 3: location of string fir the orintf statement
	starts at: 0x80484c0
	ends at  : 0x80484cf

Part 4: list of registers after 15th iteration
eax	0x10		16
ecx	0x0		0
edx	0x98e0d0	10019024
ebx	0x98cff4	10014708
esp	0xffffd330	0xffffd330
ebp	0xffffd348	0xffffd348
esi	0x831ca0	859244
edi	0x0		0
eip	0x80483ca	0x80483ca <main +38>
eflags	0x286		[PF SF IF]

*/
#include <stdlib.h>
#include <stdio.h>

int main(int argc, char *argv[]){

	int i;
	for(i = 0; i < 25; i++){

		printf("Welcome to CS261");

	}

	return 0;

}
