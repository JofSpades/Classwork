#include <stdio.h>

int main(int argc, char *argv[]) {

	if(strlen(argv[1]) != 4){

		printf("************ERROR PIN MUST BE OF LENGTH 4************\nYOU ENTERD A PIN THAT IS EITHER TOO LONG OR TOO SHORT")
	
		return 0;

	}

	srand(atoi(argv[1]));

	int shift = rand() % 25;
	int val = 0;
	char ch;
	int in[26];
	int out[26];

	for(int i = 0; i < 26; i++){

		in[i] = 97 + i;

	}

	for(int i = 0; i < 26; i++){

		out[i] = in[i] + shift;

		if(out[i] > 122){

			out[i] = 96 + (out[i] - 122);

		}

	}

	while(val != -1){

		ch = getchar();

		val = ch;

		if(val != -1){

			if(isalpha(ch)){

				ch = tolower(ch);

				for(int i = 0; i < 26; i++){


					if(in[i] == ch){

						putchar(out[i]);

						continue;
						
					}

				}

			} else {

				putchar(ch);

			}

		}

	}

	return 0;

}