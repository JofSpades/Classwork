This program as is will be compiled with "make bpop". The program will generate a 40 by 40 random board. input will be a coordinate <row> <column>.

Enjoy!
Maxwell Petersen