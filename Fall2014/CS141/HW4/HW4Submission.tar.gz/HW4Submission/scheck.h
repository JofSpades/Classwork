

int scheck(int board[9][9]);
