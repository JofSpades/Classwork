import java.io.*;
import java.net.*;
import java.util.*;
/*
 * class used to preform asynchronus update of the message board and list of connected 
 * users
 */
public class ClientUpdate extends Thread{
  private ClientList list;
  private BufferedReader in;
  private ObjectInputStream inList;
  private boolean running = true;
  //constructor
  public ClientUpdate(ClientList inList, BufferedReader inputSocket, ObjectInputStream inputListSocket){
    this.list = inList;
    this.in = inputSocket;
    this.inList = inputListSocket;
  }
  //used to recieved messages
  public void run(){
    String input = "";
    String output = "";
    String[] splitted;
    try{
      while(running){
        while((input = in.readLine()) != null){
          splitted = input.split(":");
          output = "";
          ClientList instance = this.list.getInstance();
          for(int i = 2; i < splitted.length; i++){
            output += splitted[i]+":";
          }
          output.substring(0,output.length()-1);
          if(splitted[0].equals("4")){
            System.out.println("<PRIVATE:"+instance.getUserName(Integer.parseInt(splitted[1]))+">"+output);
          } else if(splitted[1].equals("5")){
            System.out.println("<GROUP:"+instance.getUserName(Integer.parseInt(splitted[1]))+">"+output);
          } else if(splitted[1].equals("2")){
            this.list = (ClientList) this.inList.readObject();
          }
        }
      }
    } catch(Exception ex){
        System.out.println(ex.getMessage());
        System.exit(1);
    }
    try{
      this.in.close();
      this.inList.close();
    } catch (Exception ex){
      System.out.println(ex.getMessage());
    }
  }
  //update the running status
  public void notRunning(){
    this.running = false;
  }
}
