import java.net.*;
import java.io.*;
/* class used to store individual data such as:
 * socket
 * name
 * and connection number
 * the number is used to determine:
 * 1. if the user is anonymous which one it is
 * 2. faster nessage indexing and 
 * 3. smaller packet data
 */
public class ClientData{
  private int clientNumber;
  private Socket clientSocket;
  private String clientName;
  private PrintWriter clientSender;
  //default construstor
  public ClientData(int suppliedNumber, Socket suppliedSocket, String suppliedName){
    this.clientNumber = suppliedNumber;
    this.clientSocket = suppliedSocket;
    this.clientName = suppliedName;
    try{
      this.clientSender = new PrintWriter(this.clientSocket.getOutputStream(), true);
    } catch (Exception es){
      System.out.println(es.getMessage());
      System.exit(1);
    }
  }
  //annonymous constructor
  public ClientData(int suppliedNumber, Socket suppliedSocket){
    this.clientNumber = suppliedNumber;
    this.clientSocket = suppliedSocket;
    this.clientName = "user"+suppliedNumber;
    try{
      this.clientSender = new PrintWriter(this.clientSocket.getOutputStream(), true);
    } catch (Exception es){
      System.out.println(es.getMessage());
      System.exit(1);
    }
  }
  //client constructor
  public ClientData(int suppliedNumber, String suppliedName){
    this.clientNumber = suppliedNumber;
    this.clientName = suppliedName;
  }
  //get client PrintWriter
  public PrintWriter getClientSender(){
    return this.clientSender;
  }
  //get client number
  public int getClientNumber(){
    return this.clientNumber;
  }
  //get client socket
  public Socket getClientSocket(){
    return this.clientSocket;
  }
  //get client name
  public String getClientName(){
    return this.clientName;
  }
}
