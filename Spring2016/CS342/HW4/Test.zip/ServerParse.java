import java.io.*;
import java.net.*;
import java.util.*;
/*this class is the actual server thread class that will handle connections
 */
public class ServerParse extends Thread{
  private Socket client;
  private ClientList list;
  private int connectionNumber;
  private boolean connected = false;
  // thread code
  public void run(){
    try{
      BufferedReader in = new BufferedReader(new InputStreamReader(this.client.getInputStream()));
      String input = "";
      String[] split;
      //while a connection is alive
      while((input = in.readLine()) != null){
        split = input.split(":");
        ClientList instance = this.list.getInstance();
        // If not already setup will wait until a username is sent
        if(!connected){
          //getting the username message
          if(split[0].equals("0")){
            //annon user
            if(split.length == 1){
              instance.addConnection(connectionNumber, this.client);
              System.out.println("user"+connectionNumber+" connected");
            //non annon user
            } else if(split.length == 2){
              instance.addConnection(connectionNumber, this.client, split[1]);
              System.out.println(split[1]+" connected");
            //something else
            } else {
              continue;
            }
            System.out.println(instance.toString());
            connected = true;
            //sending an update for the list
            for(ClientData data:instance.getList()){
              data.getClientSender().println("2:"+instance.toString());
            }
            System.out.println("Update Sucessful");
          }
        //if connection as been estabolished
        } else {
          //check for message vs garbage
          if(split[0].equals("3")){
            String output = "";
            for(int i = 2; i < split.length; i++){
              output += split[i]+":";
            }
            output = output.substring(0, output.length()-1);
            //sending to whole group
            if((split[1].length() == 0)){
              System.out.println("<GROUP:"+instance.getUserName(this.connectionNumber)+">"+output);
              for(ClientData data:instance.getList()){
                if(data.getClientNumber() != this.connectionNumber){
                  data.getClientSender().println("4:"+this.connectionNumber+":"+output);
                }
              }
            } else {
              //sending to at least one person but less than the whole group
              String[] sendTo = split[1].split(",");
              System.out.println("<"+split[1]+":"+instance.getUserName(this.connectionNumber)+">"+output);
              for(String recipient: sendTo){
                this.list.getClient(Integer.parseInt(recipient)).getClientSender().println("5:"+this.connectionNumber+":"+output);
              }
            }
          }
        }
      }
    } catch (IOException e){
      System.out.println(e);
      System.exit(1);
    }
  }
  //constructor
  public ServerParse(Socket client, ClientList list, int connectionNumber){
    this.client = client;
    this.connectionNumber = connectionNumber;
    this.list = list;
    start();
  }
}
