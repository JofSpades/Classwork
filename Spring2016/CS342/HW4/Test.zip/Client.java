import java.io.*;
import java.net.*;
import java.util.*;
/* Class used to instantiate the client thread
 */
public class Client extends Thread{
  private String serverIP;
  private int port;
  private ClientList list;
  private Socket socket;
  private String user;
  private PrintWriter out;
  private BufferedReader in;
  private ClientUpdate updator;

  //main constructor starts main thread
  public Client(int portnumber, String serverIP, String user){
    this.serverIP = serverIP;
    this.port = portnumber;
    this.user = user;
    System.out.println("Client starting");
    try{
      this.socket = new Socket(this.serverIP, this.port);
      System.out.println("got socket");
      this.out = new PrintWriter(this.socket.getOutputStream(), true);
      System.out.println("out has been set");
      this.in = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
      System.out.println("in has been set");
    } catch (IOException e){
      System.out.println("Couldent get I/O for conenction");
      System.exit(1);
    }
    this.out.println("0:"+this.user);
    System.out.println("connected");
    try{
      String input = "";
      while((input = in.readLine()) != null){
        System.out.println(input.split(":")[1]);
        this.list.fromString(input.split(":")[1]);
        System.out.println("obtained list from server");
        break;
      }
      System.out.println("obtained list from server");
    } catch (Exception ex){
      System.out.println(ex.getMessage());
      System.exit(1);
    }
    System.out.println("here");
    System.out.println(this.list.toString());
  }
  //used to recieved messages
  public void run(){
    String input = "";
    String output = "";
    String[] splitted;
    try{
      while((input = in.readLine()) != null){
        splitted = input.split(":");
        output = "";
        ClientList instance = list.getInstance();
        for(int i = 2; i < splitted.length; i++){
          output += splitted[i]+":";
        }
        output.substring(0,output.length()-1);
        if(splitted[0].equals("4")){
          System.out.println("<PRIVATE:"+instance.getUserName(Integer.parseInt(splitted[1]))+">"+output);
        } else if(splitted[0].equals("5")){
          System.out.println("<GROUP:"+instance.getUserName(Integer.parseInt(splitted[1]))+">"+output);
        } else if(splitted[0].equals("2")){
          this.list.fromString(splitted[1]);
        }
      }
    } catch(Exception ex){
      System.out.println(ex.getMessage());
      System.exit(1);
    }
  }
  //send a message to the server to send to other persons
  public void sendMessage(int[] recipients, String message){
    String to = "";
    if(recipients != null){
      for(int recpiant: recipients){
        to += recpiant + ",";
      }
      to = to.substring(0,to.length()-1);
      this.out.println("3:"+to+":"+message);
    } else {
      this.out.println("3::"+message);
    }
  }
  //disconect message
  public void disconnect(){
    this.out.println("1::");
    this.updator.notRunning();
    try{
      this.out.close();
      this.in.close();
    } catch (Exception ex){
      System.out.println(ex.getMessage());
      System.exit(1);
    }
  }
  public static void main(String[] args){
    Client tester = new Client(10000,"127.0.0.1", "");
    System.out.println("starting the updator");
    tester.start();
    System.out.println("sending first message");
    tester.sendMessage(null,"hel:lo");
    System.out.println("waiting");
    try{
      Thread.sleep(2);
    } catch (Exception ex){
      System.out.println(ex.getMessage());
      tester.disconnect();
      System.exit(1);
    }
    System.out.println("sending second message");
    tester.sendMessage(null,"goodbye");
    System.out.println("disconnecting");
    tester.disconnect();
  }
}
