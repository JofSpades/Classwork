import java.net.*;
 
public class test {
  public static void main(String[] args) throws Exception {
    InetAddress addr = InetAddress.getLocalHost();
    System.out.println(addr);
    System.out.println(addr.getHostName());
    System.out.println(addr.getHostAddress());
  }
}
