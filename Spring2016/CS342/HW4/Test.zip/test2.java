import java.util.*;
import java.io.*;
public class test2{
  public static void main(String[] args){
    String test = "3::hello";
    String test2 = "3:4,5:hello";
    String[] testArr = test.split(":");
    String[] test2Arr = test2.split(":");
    System.out.println(testArr[1]+":"+testArr[1].length());
    System.out.println(test2Arr[1]+":"+test2Arr[1].length());
  }
}
