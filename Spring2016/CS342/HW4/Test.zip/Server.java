import java.io.*;
import java.net.*;
import java.util.*;
/* server main thread/program that listens for connections and handles
 * the interweaving of messages
 */
public class Server extends Thread{
  private ClientList list;
  private ServerSocket socket;
  private InetAddress address;
  private boolean running = true;
  private int port;

  //main constructor/main thread
  public Server(int portnumber){
    this.port = portnumber;
    System.out.println("Server starting");
    start();
  }
  public void run(){
    int connections = 0;
    this.list = list.getInstance();
    try{
      this.address = InetAddress.getLocalHost();
      System.out.println(this.address);
    } catch (UnknownHostException e){
      System.out.println("Cannot get host address");
      this.address = null;
    }
    try{
      this.socket = new ServerSocket(this.port);
      try{
        while(this.running){
          new ServerParse(this.socket.accept(), this.list, connections);
          connections++;
        }
      } catch (IOException e){
        System.out.println("Accecpt failed");
        System.exit(1);
      }
    } catch (IOException e){
      System.out.println("Connection failed");
      System.exit(1);
    }
    finally{
      try{
        System.out.println("Server closing");
        this.socket.close();
      } catch (IOException e){
        System.out.println("Close failed");
        System.exit(1);
      }
    }
  }
  //get the host name/IP
  public String getIP(){
    return this.address.getHostAddress();
  }
  public void setRunning(boolean bool){
    this.running = bool;
  }
  public static void main(String[] args){
    new Server(10000);
  }
}
