import java.util.*;
import java.net.*;
import java.io.*;
/* this class is a singleton desigend list of all connected clients
 * that is then shared inbetween the server and the connected clients so every one
 * knows who is conencted at all times
 */
public class ClientList implements Serializable{
  private Vector<ClientData> list;
  private static ClientList instance = new ClientList();
  
  //private constrctor as per sigleton implamentation requirements
  private ClientList(){
    this.list = new Vector<ClientData>();
  }
  //gets instance of clientList
  public synchronized static ClientList getInstance(){
    if(instance == null){
      instance = new ClientList();
      return instance;
    } else {
      return instance;
    }
  }
  //gets list of clients
  public synchronized Vector<ClientData> getList(){
    return this.instance.getInstance().list;
  }
  //adds new connection given a ClientData object
  public synchronized void addConnection(ClientData newData){
    ClientList instance = this.getInstance();
    this.list.addElement(newData);
  }
  //adds new connection given connection number and socket
  public synchronized void addConnection(int suppliedNumber, Socket suppliedSocket){
    ClientList instance = this.getInstance();
    instance.list.addElement(new ClientData(suppliedNumber, suppliedSocket));
  }
  //adds new connection given all data needed
  public synchronized void addConnection(int suppliedNumber, Socket suppliedSocket, String suppliedName){
    ClientList instance = this.getInstance();
    instance.list.addElement(new ClientData(suppliedNumber, suppliedSocket, suppliedName));
  }
  //used for clients only
  public synchronized void addConnection(int suppliedNumber, String suppliedName){
    ClientList instance = this.getInstance();
    instance.list.addElement(new ClientData(suppliedNumber, suppliedName));
  }
  //converts vector to sendable string format
  public synchronized String toString(){
    ClientList instance = this.getInstance();
    String retval = "";
    for(ClientData data:instance.list){
      retval += data.getClientNumber()+","+data.getClientName()+";";
    }
    return retval;
  }
  //connverts the recieved user list to vector elements
  public synchronized void fromString(String inString){
    ClientList instance = this.getInstance();
    instance.list.clear();
    System.out.println("in fromString");
    System.out.println(inString);
    String[] individualConnections = inString.split(";");
    for(String connection: individualConnections){
      System.out.println(connection);
      if(!connection.equals("")){
        String[] dataElements = connection.split(",");
        instance.list.addElement(new ClientData(Integer.parseInt(dataElements[0]),dataElements[1]));
      }
    }
  }
  //checks existance of username
  public synchronized boolean isUser(String name){
    ClientList instance = this.getInstance();
    for(ClientData data: instance.list){
      if(name.equals(data.getClientName())){
        return true;
      }
    }
    return false;
  }
  //gets connection number of a username
  public synchronized int getUserNumber(String name){
    ClientList instance = this.getInstance();
    if(instance.isUser(name)){
      for(ClientData data: instance.list){
        if(name.equals(data.getClientName())){
          return data.getClientNumber();
        }
      }
    }
    return -1;
  }
  //gets connection name of a certain connection number
  public synchronized String getUserName(int number){
    ClientList instance = this.getInstance();
    for(ClientData data:instance.list){
      if(number == data.getClientNumber()){
        return data.getClientName();
      }
    }
    return null;
  }
  //gets connection object
  public synchronized ClientData getClient(int number){
    ClientList instance = this.getInstance();
    for(ClientData data:instance.list){
      if(number == data.getClientNumber()){
        return data;
      }
    }
    return null;
  }
}
